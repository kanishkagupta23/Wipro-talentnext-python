# Input string
input_string = "Hi Alex WelcomeAlex Bye Alex."

# Substring to count
name_to_count = "Alex"

# Counting occurrences
count = input_string.count(name_to_count)

# Output the result
print(count)